#ifndef CAT_FE_HPP
#define CAT_FE_HPP

#include "fp.hpp"

namespace cat {


struct ufe {
	ufp a, b;
};


} // namespace cat

#endif // CAT_FE_HPP

